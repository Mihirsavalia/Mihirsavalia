require('dotenv').config();
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const mongoose = require('mongoose');
// const flash = require('connect-flash')
const multer = require('multer');

const port = process.env.PORT;
const MONGODB_URI = process.env.MONGODB_URI;

const error404 = require('./controllers/error.controller')
const usersRouter = require('./routes/user.routes');

const app = express();

// view engine setup
app.set('view engine', 'ejs');
app.set('views', 'views');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads')
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname.split('.')[0] + "_" + Date.now()+"."+file.originalname.split('.')[1])
        // cb(null,path.extname(file.fieldname)+"-"+Date.now())
    }
});

const fileFilter = (req, file, cb) => {
  const fileTypes = /jpeg|jpg|png|gif/;
  const extname = fileTypes.test(file.originalname);
  const mimetype = fileTypes.test(file.mimetype);

  if (mimetype && extname) {
      return cb(null, true)
  }
  else {
      cb('Error : Images only!')
  }
}
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: false }));
app.use(multer({storage: storage,fileFilter: fileFilter}).single("image"))
app.use(cookieParser());

// app.use(flash());
app.use(usersRouter);

// catch 404 and forward to error handler
app.use(error404.get404);
mongoose.set('strictQuery',true);

mongoose.connect(MONGODB_URI)
.then(()=>{
  app.listen(port, () => {
    console.log(`Server Is Running On http://localhost: ${port}`)
  })
})
.catch(err=>console.log(err))


// PORT = 4040
// JWT_SECRET_KEY = 'secretKey'
// MONGODB_URI = 'mongodb://localhost:27017/nodeExam'
// # MONGODB_URI = 'mongodb+srv://root:root@cluster0.pubruui.mongodb.net/nodeExam?retryWrites=true&w=majority'

// PUBLISHABLE_KEY = 'pk_test_51MgYGySAHzGaxVytC9pA8WaNUbXzkoYNB3cOx1F3DbrcG05bfsdaFWCfOxrmpnrtLCHUXukoOkC36eJ47HjGZwYZ00ksiSqbGU'
// SECRET_KEY = 'sk_test_51MgYGySAHzGaxVytgsgN6ilu5bbf92nCJr8jv4cUVSisdudDDFUxA9VP2wcon1y2wzzs6DIzoB2HtRs6ZGL6Gq7H00scovJBEa'