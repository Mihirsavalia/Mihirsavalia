require('dotenv').config()
const jwt = require('jsonwebtoken');
const { isJwtExpired } = require('jwt-check-expiration');
const User = require('../models/user.models');

const authenticateToken = (req, res, next) => {

    const token = req.cookies.token;
    const expiredToken = isJwtExpired(token);
    
    if (!expiredToken) {
        const bearerToken = jwt.verify(token, process.env.JWT_SECRET_KEY);
        if (bearerToken) {
            User.findOne({ email: bearerToken.userEmail })
                .then(user => {
                    email = user.email;
                    role = user.role;
                    userId = user._id;
                    userName = user.name;
                    stripeCustomerId = user.stripeCustomerId;
                    next();
                })
                .catch(err => console.log(err));
        }
        else {
            res.redirect('/');
        }
    } else {
        res.redirect('/');
    }
}

module.exports = authenticateToken;
