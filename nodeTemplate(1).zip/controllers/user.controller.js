require('dotenv').config()

const bcrypt = require('bcryptjs');
const User = require('../models/user.models');
const Service = require('../models/service.models');
const OTP = require('../models/otp.models');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const { validationResult } = require('express-validator');
const puppeteer = require('puppeteer');




const PUBLISHABLE_KEY = process.env.PUBLISHABLE_KEY;
const SECRET_KEY = process.env.SECRET_KEY;

const stripe = require('stripe')(SECRET_KEY)

const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    requireTLS: true,
    auth: {
        user: "mihirsavaliya758@gmail.com",
        pass: "dnhltdtiedgkwrhq"
    }
});

exports.createCustomer = (req, res, next) => {
    var param = {};
    param.email = "mihir13@gmail.com";
    param.name = "TMS";
    param.description = "A Great Person";

    stripe.customers.create(param)
        .then(result => {
            console.log("Success")
        })
        .catch(err => console.log(err))
}

exports.retrieveCustomer = (req, res, next) => {
    stripe.customers.retrieve("cus_NS3UY7tKPlkeM6")
        .then(result => {
            console.log("Success", JSON.stringify(result, null, 2))
        })
        .catch(err => console.log(err))
}
exports.retrieveAllCustomer = (req, res, next) => {
    stripe.customers.list()
        .then(result => {
            for (let i = 0; i < result.data.length; i++) {
                console.log("🚀 ~ file: user.controller.js:50 ~ result:", result.data[i].name)
            }
        })
        .catch(err => console.log(err))
}
// exports.createCardToken = (req, res, next) => {
//     let param = {};
//     param.card = {
//         number: '5200828282828210',
//         exp_month: 11,
//         exp_year: 2024,
//         cvc: '121'
//     }
//     stripe.tokens.create(param)
//         .then(result => {
//             console.log("Success")
//         })
//         .catch(err => console.log(err))
// }

exports.retrieveCard = (req, res, next) => {
    stripe.customers.retrieveSource('cus_NS3VLoVCcg72QC', 'card_1Mh9WgSAHzGaxVytByTYrh4T')
        .then(result => {
            console.log("Success", JSON.stringify(result.last4, null, 2))
        })
        .catch(err => console.log(err))
}
exports.getAddCard = (req, res, next) => {
    res.render('addCard', {
        path: '/billing',
        userName: userName,
        role: role,
        pageTitle: 'Add Card',
    });
}

exports.postAddCard = (req, res, next) => {
    const { card_number, card_holder_name, month, year, cvv } = req.body;
    User.findOne({ email: email })
        .then(cust_id => {
            let param = {};
            param.card = {
                number: card_number,
                name: card_holder_name.toUpperCase(),
                exp_month: month,
                exp_year: year,
                cvc: cvv
            }
            stripe.tokens.create(param)
                .then(result => {
                    let params = {
                        source: result.id
                    }
                    stripe.customers.createSource(cust_id.stripeCustomerId, params)
                        .then(result => {
                            console.log("Success");
                            res.redirect('/billing');
                        })
                        .catch(err => console.log(err))
                })
                .catch(err => console.log(err))


        })
        .catch(err => console.log(err))

}

// exports.addNewCard = (req, res, next) => {
//     let param2 = {
//         source: 'tok_1Mh7vhSAHzGaxVytt3baDsfX'
//     }
//     stripe.customers.createSource('cus_NRoaiY8IAZSox6', param2)
//         .then(result => {
//             console.log("Success")
//         })
//         .catch(err => console.log(err))
// }

exports.getLogin = (req, res, next) => {
    res.render('login', {
        path: '/login',
        pageTitle: 'Login',
        oldValue: '',
        msg: '',
        validationErrors: []

    });
}

exports.postLogin = (req, res, next) => {
    const { email, password } = req.body;

    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        const alert = errors.array()[0].msg;

        res.render('login', {
            alert,
            msg: '',
            path: '/login',
            pageTitle: 'Login',
            oldValue: req.body,
            validationErrors: errors.array()

        });
    }
    else {
        // function changeOTP() {
        //     generateOtp = 0;
        // }
        // setTimeout(changeOTP, 300000);

        User.findOne({ email: email })
            .then(user => {
                if (!user) {
                    console.log("You are not registred user")
                    res.redirect('/login')
                }
                else {
                    bcrypt.compare(password, user.password)
                        .then(match => {
                            if (match) {
                                let generateOtp = Math.floor(1000 + Math.random() * 9000);
                                console.log("🚀 ~ file: user.controller.js:63 ~ generateOtp:", generateOtp)

                                const token = jwt.sign(
                                    { userEmail: user.email },
                                    process.env.JWT_SECRET_KEY,
                                    { expiresIn: '2h' }
                                );

                                res.cookie('token', token, { httpOnly: true });

                                //Send Email
                                const message = {
                                    from: 'mihirsavaliya758@gmail.com',
                                    to: email,
                                    subject: 'OTP',
                                    html: `<p>Your Login OTP is : <b>${generateOtp}</b>. It's valid upto 5 minutes.</p>`
                                };
                                transporter.sendMail(message, (error, info) => {
                                    if (error) {
                                        console.log(error)
                                    }
                                    else {
                                        console.log('Email sent ...', info.response)
                                    }
                                })

                                //OTP generate
                                const saltRounds = 10;
                                return bcrypt.hash(String(generateOtp), saltRounds)
                                    .then(hasedOtp => {

                                        const otpModel = new OTP({
                                            userId: user._id,
                                            otp: hasedOtp
                                        })

                                        OTP.findOneAndDelete({ userId: user._id })
                                            .then((result) => {
                                                otpModel.save();
                                                res.redirect('/otp')
                                            })
                                            .catch(err => console.log(err))
                                    })
                                    .catch(err => console.log(err))
                            }
                            else {
                                res.render('login', {
                                    msg: 'Invalid Password',
                                    path: '/login',
                                    pageTitle: 'Login',
                                    oldValue: req.body,
                                    validationErrors: []
                                });
                            }
                        })
                        .catch(err => console.log(err))
                }
            })
            .catch(err => console.log(err))
    }
}

exports.getDashboard = (req, res, next) => {
    res.render('dashboard', {
        userName: userName,
        role: role,
        path: '/dashboard',
        pageTitle: 'Dashboard'
    });

}

exports.getSignup = (req, res, next) => {
    res.render('signup', {
        path: '/signup',
        pageTitle: 'Sign up',
        oldValue: '',
        validationErrors: []
    });
}

exports.postSignup = (req, res, next) => {
    const { name, email, password, phone_no } = req.body;
    const image = req.file;
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const alert = errors.array()[0].msg;
        res.render('signup', {
            alert,
            path: '/signup',
            pageTitle: 'Sign up',
            oldValue: req.body,
            validationErrors: errors.array()
        });
    }
    else {
        User.findOne({ email: email })
            .then(userData => {
                return bcrypt.hash(password, 12)
                    .then(hashPasswrod => {

                        var param = {};
                        param.email = email;
                        param.name = name;

                        stripe.customers.create(param)
                            .then(result => {
                                const user = new User({
                                    name: name,
                                    email: email,
                                    password: hashPasswrod,
                                    phone_no: phone_no,
                                    role: 2,
                                    stripeCustomerId: result.id,
                                    userProfileImage: image.filename
                                })
                                user.save();
                                console.log("Success")
                            })
                            .catch(err => console.log(err));
                        res.redirect('login');
                    })
                    .catch(err => console.log(err))
            })
            .catch(err => console.log(err))
    }

}

exports.getDisplay = (req, res, next) => {
    if (role == 1) {
        User.find()
            .then(user => {
                Service.find()
                    .then(service => {
                        res.render('display', {
                            userName: userName,
                            services: service,
                            users: user,
                            role: role,
                            path: '/display',
                            pageTitle: 'Display',
                        });
                    })
                    .catch(err => console.log(err))
            })
            .catch(err => console.log(err))
    }
    else {
        Service.find({ userId: userId })
            .then(service => {
                res.render('customerDisplay', {
                    userName: userName,
                    services: service,
                    role: role,
                    path: '/display',
                    pageTitle: 'Display',
                });
            })
            .catch(err => console.log(err))
    }

}

exports.getAddServices = (req, res, next) => {
    User.find()
        .then(user => {
            res.render('addServices', {
                userName: userName,
                users: user,
                role: role,
                path: '/addServices',
                pageTitle: 'Add Service'
            });
        })
        .catch(err => console.log(err))
}

exports.postAddServices = (req, res, next) => {
    const { name, email, vehicle_no, pickup_date, drop_date } = req.body;

    User.findOne({ email: email })
        .then(user => {
            const service = new Service({
                customer_name: name,
                email: email,
                vehicle_no: vehicle_no,
                pickup_date: pickup_date,
                drop_date: drop_date,
                userId: user._id
            })
            service.save()
            const message = {
                from: 'mihirsavaliya758@gmail.com',
                to: "abc@gmail.com",
                subject: 'OTP',
                html: `<h3>Your Service Successfully Added.
                    Thank You</h3>`
            };
            transporter.sendMail(message, (error, info) => {
                if (error) {
                    console.log(error)
                }
                else {
                    console.log('Email sent ...', info.response)
                }
            })
            res.redirect('display');
        })
        .catch(err => console.log(err))
}

exports.getOtp = (req, res, next) => {
    res.render('otp',
        {
            msg: '',
            path: '/otp',
            pageTitle: 'OTP'
        });
}

exports.postOtp = (req, res, next) => {
    const otp = String(req.body.otp);

    OTP.findOne({ userId: userId })
        .then(otps => {
            if (!otps) {
                console.log("otp is expired")
                res.redirect('/login')
            }
            else {
                bcrypt.compare(otp, otps.otp)
                    .then(match => {
                        if (match) {
                            OTP.findOneAndDelete({ userId })
                                .then(result => {
                                    res.redirect('/dashboard')
                                })
                                .catch(err => console.log(err));
                        }
                        else {
                            res.render('otp',
                                {
                                    msg: 'OTP is not correct',
                                    path: '/otp',
                                    pageTitle: 'OTP'
                                });
                        }
                    })
            }
        })
        .catch(err => console.log(err))
}

exports.getLogout = (req, res, next) => {
    res.clearCookie("token");
    res.redirect('/');
}

exports.getResetEmail = (req, res, next) => {
    res.render('resetEmail', {
        path: '/resetEMail',
        pageTitle: 'Sent Email',
        validationErrors: []
    });
}

exports.postResetEmail = (req, res, next) => {
    const { email } = req.body;
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        const alert = errors.array()[0].msg;
        res.render('resetEmail', {
            alert,
            path: '/resetEMail',
            pageTitle: 'Sent Email',
            validationErrors: errors.array()
        });
    }
    else {
        User.findOne({ email: email })
            .then(user => {
                if (!user) {
                    res.send({ "status": "failed", "message": "You are not registred user" })
                    return res.redirect('/resetEmail')
                }
                else {
                    const message = {
                        from: 'mihirsavaliya758@gmail.com',
                        to: email,
                        subject: 'OTP',
                        html: `<p>Password Reset Link is : </p><a href='http://localhost:4040/forgetPassword/${user._id}'>Reset Password</a>`
                    };
                    transporter.sendMail(message, (error, info) => {
                        if (error) {
                            console.log(error)
                        }
                        else {
                            console.log('Email sent ...', info.response)
                        }
                    })
                    res.redirect('/login');
                }
            })
            .catch(err => console.log(err));
    }

}

exports.getForgetPassword = (req, res, next) => {
    const resetId = req.params.resetId;
    res.render('forgetPassword', {
        resetId: resetId,
        path: '/forgetPassword',
        pageTitle: 'Forget Password',
        validationErrors: []
    });
}

exports.postForgetPassword = (req, res, next) => {
    const { password, confirm_password, resetId } = req.body;
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const alert = errors.array()[0].msg;
        res.render('forgetPassword', {
            alert,
            resetId: resetId,
            path: '/forgetPassword',
            pageTitle: 'Forget Password',
            oldValue: req.body,
            validationErrors: errors.array()
        });
    }
    else {
        console.log("🚀 ~ file: user.controller.js:405 ~ result:")
        return bcrypt.hash(password, 12)
            .then(hashPassword => {
                User.findByIdAndUpdate({ _id: resetId })
                    .then(result => {
                        result.password = hashPassword;
                        result.save()
                        res.redirect('/login')
                    })
                    .catch(err => console.log(err))
            });
    }

}

exports.getAddAdmin = (req, res, next) => {
    res.render('addAdmin', {
        path: '/addAdmin',
        pageTitle: 'Add User',
        oldValue: '',
        validationErrors: []
    });
}

exports.postAddAdmin = (req, res, next) => {
    const { name, email, password, phone_no, role } = req.body;
    const image = req.file;
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const alert = errors.array()[0].msg;
        res.render('addAdmin', {
            alert,
            path: '/addAdmin',
            pageTitle: 'Add User',
            oldValue: req.body,
            validationErrors: errors.array()
        });
    }
    else {
        User.findOne({ email: email })
            .then(userData => {
                return bcrypt.hash(password, 12)
                    .then(hashPasswrod => {

                        var param = {};
                        param.email = email;
                        param.name = name;

                        stripe.customers.create(param)
                            .then(result => {
                                const user = new User({
                                    name: name,
                                    email: email,
                                    password: hashPasswrod,
                                    phone_no: phone_no,
                                    role: role,
                                    stripeCustomerId: result.id,
                                    userProfileImage: image.filename
                                })
                                user.save();
                                console.log("Success")
                            })
                            .catch(err => console.log(err));
                        res.redirect('dashboard');
                    })
                    .catch(err => console.log(err))
            })
            .catch(err => console.log(err))
    }
}

exports.getBilling = (req, res, next) => {
    const payment_service_id = req.query.payment_service_id;
    stripe.paymentMethods.list({ customer: stripeCustomerId, type: 'card' })
        .then(result => {
            res.render('billing', {
                path: '/billing',
                pageTitle: 'Billing',
                key: PUBLISHABLE_KEY,
                result: result,
                payment_service_id: payment_service_id
            });
        })
        .catch(err => console.log(err))

}

exports.postBilling = (req, res, next) => {
    const { card_payment, payment_service_id } = req.body;
    Service.findOne({ _id: payment_service_id })
        .then(service => {
            User.findOne({ email: service.email })
                .then(user => {
                    res.render('checkout', {
                        path: '/billing',
                        pageTitle: 'Checkout',
                        service: service,
                        user: user,
                        card_payment: card_payment,
                        payment_service_id: payment_service_id
                    });
                })
        })
        .catch(err => console.log(err))

}

exports.getCheckout = (req, res, next) => {
    const { card_payment, payment_service_id } = req.body;
    Service.findOne({ _id: payment_service_id })
        .then(service => {
            User.findOne({ email: service.email })
                .then(user => {
                    res.render('checkout', {
                        path: '/billing',
                        pageTitle: 'Checkout',
                        service: service,
                        user: user,
                        card_payment: card_payment,
                        payment_service_id: payment_service_id
                    });
                })
        })
        .catch(err => console.log(err))
}


exports.postCheckout = (req, res, next) => {
    const { card_payment, payment_service_id, payment_amount, stripe_cust_id } = req.body;
    let paymentOtp = Math.floor(100000 + Math.random() * 9000);
    console.log("🚀 ~ file: user.controller.js:643 ~ paymentOtp:", paymentOtp)
    Service.findOne({ _id: payment_service_id })
        .then(service => {
            User.findOne({ email: service.email })
                .then(user => {

                    //send email
                    const message = {
                        from: 'mihirsavaliya758@gmail.com',
                        to: email,
                        subject: 'OTP',
                        html: `<p>Your payment OTP is : <b>${paymentOtp}</b>. It's valid upto 30 seconds.</p>`
                    };
                    transporter.sendMail(message, (error, info) => {
                        if (error) {
                            console.log(error)
                        }
                        else {
                            console.log('Email sent ...', info.response)
                        }
                    })
                    //OTP Store in database
                    const saltRounds = 10;
                    bcrypt.hash(String(paymentOtp), saltRounds)
                        .then(hasedOtp => {

                            const otpModel = new OTP({
                                userId: user._id,
                                otp: hasedOtp
                            })

                            OTP.findOneAndDelete({ userId: user._id })
                                .then(result => {
                                    otpModel.save();
                                })
                        })

                    //paymentIntent
                    stripe.paymentIntents.create({
                        amount: payment_amount * 100,
                        currency: 'inr',
                        payment_method_types: ['card'],
                        // setup_future_usage: 'off_session',   
                        customer: stripe_cust_id,
                    }, { stripeAccount: 'acct_1MgYGySAHzGaxVyt' })

                        .then(paymentIntent => {
                            stripe.customers.retrieveSource(stripe_cust_id, card_payment)
                                .then(result => {
                                    res.render('verifyCardOTP', {
                                        path: '/billing',
                                        pageTitle: 'Verify OTP',
                                        card_details: result,
                                        userCardId: user._id,
                                        card_payment: card_payment,
                                        paymentIntent: paymentIntent.id,
                                        stripe_cust_id: stripe_cust_id,
                                        msg: ''
                                    })
                                })
                                .catch(err => console.log(err))
                        })
                })
                .catch(err => console.log(err))
        })
        .catch(err => console.log(err))
}

exports.getCheckoutSuccess = (req, res, next) => {
    res.render('checkoutSuccess', {
        path: '/billing',
        pageTitle: 'Checkout Success',
    });
}

exports.getDisplayServices = (req, res, next) => {
    const cust_id = req.query.cust_id;
    User.findOne({ _id: cust_id })
        .then(user => {
            Service.find({ userId: cust_id })
                .then(service => {
                    res.render('displayServices', {
                        userName: userName,
                        services: service,
                        users: user,
                        role: role,
                        path: '/display',
                        pageTitle: 'Display Services'
                    });
                })
                .catch(err => console.log(err))
        })
        .catch(err => console.log(err))
}

exports.getUpdateUser = (req, res, next) => {
    const cust_id̥ = req.query.cust_id;
    User.findOne({ _id: cust_id̥ })
        .then(user => {
            res.render('updateUser', {
                path: '/display',
                pageTitle: 'Update User',
                role: role,
                users: user,
                oldValue: '',
                validationErrors: []
            });
        })
        .catch(err => console.log(err))
}

exports.postUpdateUser = (req, res, next) => {
    const { name, role, email, password, phone_no, cust_id } = req.body;
    const image = req.file;
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const alert = errors.array()[0].msg;
        res.render('updateUser', {
            alert,
            path: '/display',
            pageTitle: 'Update User',
            validationErrors: errors.array()
        });
    }
    else {
        User.findByIdAndUpdate({ _id: cust_id })
            .then(result => {
                return bcrypt.hash(password, 12)
                    .then(hashPasswrod => {
                        result.name = name;
                        result.email = email;
                        result.password = hashPasswrod;
                        result.phone_no = phone_no;
                        result.role = role;
                        result.stripeCustomerId = result.stripeCustomerId;
                        result.userProfileImage = image.filename;
                        result.save();
                        console.log("User Updated")
                        res.redirect('display');
                    })
                    .catch(err => console.log(err))
            })
            .catch(err => console.log(err))
    }
}

exports.getDeleteUser = (req, res, next) => {
    const cust_id = req.query.cust_id;
    console.log("🚀 ~ file: user.controller.js:759 ~ exports.getDeleteUser ~ cust̥_id̥:", cust_id)
    User.softDelete({ _id: cust_id })
        .then(user => {
            console.log("User Soft Deleted")
            res.redirect('/display')
        })
        .catch(err => console.log(err))
}

exports.getverifyCardOTP = (req, res, next) => {
    res.render('verifyCardOTP', {
        path: '/billing',
        pageTitle: 'Verify OTP',
        card_details: '',
        msg: '',
        userCardId: '',
        paymentIntent: ''
    });
}

exports.postverifyCardOTP = (req, res, next) => {
    const { userCardId, paymentIntent, card_payment } = req.body;
    const card_otp = String(req.body.card_otp);

    OTP.findOne({ userId: userCardId })
        .then(otps => {
            if (!otps) {
                console.log("otp is expired")
                res.redirect('/display')
            }
            else {
                bcrypt.compare(card_otp, otps.otp)
                    .then(match => {
                        if (match) {
                            stripe.paymentIntents.confirm(
                                paymentIntent,
                                { payment_method: card_payment }
                            )
                                .then(result => {
                                    OTP.findOneAndDelete({ userCardId })
                                        .then(result => {
                                            res.redirect('/checkoutSuccess')
                                        })
                                        .catch(err => console.log(err));
                                })
                        }
                        else {
                            res.redirect('/display');
                        }
                    })
            }
        })
        .catch(err => console.log(err))
}

