const mongoose = require('mongoose');
// const { softDeletePlugin } = require('soft-delete-plugin-mongoose');
// const mongooseSoftDelete = require('mongoose-softdelete');
// const softDeleteMongoose = require('soft-delete-mongoose');

// const { softDelete } = require('soft-delete-mongoose-plugin');

const Schema = mongoose.Schema;

const userSchema = new Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
    },
    password: {
        type: String,
        required: true,
    },
    phone_no: {
        type: Number,
        required: true
    },
    role: {
        type: Number,
        required: true
    },
    stripeCustomerId: {
        type: String,
        required: true,
    },
    userProfileImage: {
        type: String
    },
    createdAt: Date
});

// userSchema.plugin(softDeletePlugin);

module.exports = mongoose.model('User', userSchema);