const mongoose = require('mongoose');
const DateOnly = require('mongoose-dateonly')(mongoose);

const Schema = mongoose.Schema;

const userSchema = new Schema({
    customer_name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
    },
    vehicle_no: {
        type: String,
        required: true
    },
    pickup_date: {
        type: DateOnly,
        required: true
    },
    drop_date: {
        type: DateOnly,
        required: true
    },
    userId: {
        type: Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    createdAt: Date

});

module.exports = mongoose.model('Service', userSchema);