const express = require('express');
const router = express.Router();

const { check, body } = require('express-validator');

const User = require('../models/user.models');

const userController = require('../controllers/user.controller');
const isAuth = require('../middleware/isAuth.middleware');

/* GET home page. */
router.get('/', userController.getLogin);

router.get('/dashboard', isAuth, userController.getDashboard);

router.get('/signup', userController.getSignup);

router.post('/signup',
    check('name', 'Name should not be empty')
        .notEmpty(),
    check('email', 'Please enter a valid email')
        .isEmail()
        .notEmpty()
        .custom((value, { req }) => {
            return User.findOne({ email: value })
                .then(result => {
                    if (result) {
                        return Promise.reject('Email already exists, please pick a different one.');
                    }
                })
        }),
    body('password', 'Password Length must be 8 digit.')
        .isAlphanumeric()
        .isLength({ min: 8 })
        .notEmpty()
        .trim(),
    body('confirm_password')
        .notEmpty()
        .custom((value, { req }) => {
            if (value != req.body.password) {
                throw new Error('Confirm password does not match with password')
            }
            return true;
        })
        .trim(),
    check('phone_no', "Phone Number must be in numeric and 10 digit only")
        .isLength({ min: 10, max: 10 })
        .isNumeric()
        .notEmpty()
    , userController.postSignup);

router.get('/login', userController.getLogin);

router.post('/login',
    check('email', 'Please enter a valid email')
        .isEmail()
        .notEmpty()
        .custom((value, { req }) => {
            return User.findOne({ email: value })
                .then(result => {
                    if (!result) {
                        return Promise.reject('Email does not exist');
                    }
                })
        })
        .normalizeEmail(),
    check('password', 'Password Length must be 8 digit')
        .notEmpty()
        .isLength({ min: 8 })
        .trim(),
    userController.postLogin);

router.get('/resetEmail', userController.getResetEmail);
router.post('/resetEmail',
    check('email')
        .isEmail()
        .notEmpty()
        .custom((value, { req }) => {
            return User.findOne({ email: value })
                .then(result => {
                    if (!result) {
                        return Promise.reject('Email does not exist');
                    }
                })
        })
        .normalizeEmail(),
    userController.postResetEmail);

router.get('/forgetPassword/:resetId', userController.getForgetPassword);

router.post('/forgetPassword',
    body('password', 'Password Length must be 8 digit.')
        .isAlphanumeric()
        .isLength({ min: 8 })
        .notEmpty()
        .trim(),
    body('confirm_password')
        .notEmpty()
        .custom((value, { req }) => {
            if (value != req.body.password) {
                throw new Error('Confirm password does not match with password')
            }
            return true;
        })
        .trim(), userController.postForgetPassword);

router.get('/billing', isAuth, userController.getBilling);
router.post('/billing', isAuth, userController.postBilling);

// router.get('/checkout', isAuth, userController.getCheckout);
router.post('/checkout', isAuth, userController.postCheckout);

router.get('/checkoutSuccess', isAuth, userController.getCheckoutSuccess);
// router.post('/checkoutSuccess', isAuth, userController.postCheckoutSuccess);

router.get('/display', isAuth, userController.getDisplay);
router.get('/customerDisplay', isAuth, userController.getDisplay);

router.get('/displayServices', isAuth, userController.getDisplayServices);


router.get('/addServices', isAuth, userController.getAddServices);
router.post('/addServices', isAuth, userController.postAddServices);

router.get('/otp', isAuth, userController.getOtp);
router.post('/otp', isAuth, userController.postOtp);

router.get('/addAdmin', isAuth, userController.getAddAdmin);

router.post('/addAdmin', isAuth,
    check('name', 'Name should not be empty')
        .notEmpty(),
    check('email', 'Please enter a valid email')
        .isEmail()
        .notEmpty()
        .custom((value, { req }) => {
            return User.findOne({ email: value })
                .then(result => {
                    if (result) {
                        return Promise.reject('Email already exists, please pick a different one.');
                    }
                })
        }),
    check('password', 'Password Length must be 8 digit.')
        .isAlphanumeric()
        .isLength({ min: 8 })
        .notEmpty(),
    check('confirm_password')
        .notEmpty()
        .custom((value, { req }) => {
            if (value != req.body.password) {
                throw new Error('Confirm password does not match with password')
            }
            return true;
        }),
    check('phone_no', "Phone Number must be in numeric and 10 digit only")
        .isLength({ min: 10, max: 10 })
        .isNumeric()
        .notEmpty(),
    userController.postAddAdmin);

router.get('/logout', isAuth, userController.getLogout);


router.get('/addCard', isAuth, userController.getAddCard);
router.post('/addCard', isAuth, userController.postAddCard);

router.get('/verifyCardOTP', isAuth, userController.getverifyCardOTP);
router.post('/verifyCardOTP', isAuth, userController.postverifyCardOTP);

router.get('/updateUser', isAuth,
    check('name', 'Name should not be empty')
        .notEmpty(),
    check('email', 'Please enter a valid email')
        .isEmail()
        .notEmpty()
        .custom((value, { req }) => {
            return User.findOne({ email: value })
                .then(result => {
                    if (result) {
                        return Promise.reject('Email already exists, please pick a different one.');
                    }
                })
        }),
    check('password', 'Password Length must be 8 digit.')
        .isAlphanumeric()
        .isLength({ min: 8 })
        .notEmpty(),
    check('confirm_password')
        .notEmpty()
        .custom((value, { req }) => {
            if (value != req.body.password) {
                throw new Error('Confirm password does not match with password')
            }
            return true;
        }),
    check('phone_no', "Phone Number must be in numeric and 10 digit only")
        .isLength({ min: 10, max: 10 })
        .isNumeric()
        .notEmpty(),
    userController.getUpdateUser);
router.post('/updateUser',userController.postUpdateUser);

router.get('/deleteUser',userController.getDeleteUser);

router.get('/createCustomer', userController.createCustomer);
router.get('/retrieveCustomer', userController.retrieveCustomer);
router.get('/retrieveAllCustomer', userController.retrieveAllCustomer);
router.get('/retrieveCard', userController.retrieveCard);

module.exports = router;
