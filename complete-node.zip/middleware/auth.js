require('dotenv').config()
const jwt = require('jsonwebtoken');
const { isJwtExpired } = require('jwt-check-expiration');

const authenticateToken = (req, res, next) => {
  const token = req.cookies.token;
  const refreshToken = isJwtExpired(token);
  if (!refreshToken) {
    const bearerToken = jwt.verify(token, process.env.JWT_SECRET_KEY);
    if (bearerToken) {
      next();
    }
    else {
      res.redirect('/login');
    }
  } else {
    res.redirect('/login');
  }
}

module.exports = authenticateToken;
