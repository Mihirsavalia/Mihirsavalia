require('dotenv').config()

const express = require('express');

const authController = require('../controller/auth');
const isAuth = require('../middleware/isAuthMiddleware');
const jwt = require('jsonwebtoken');


const router = express.Router();

router.get('/login', authController.getLogin);
router.post('/login', authController.postLogin);

// router.post('/changepassword',isAuth,authController.postChangePassword);

router.get('/logout', authController.postLogout);

router.get('/otp', authController.getOtp);
router.post('/otp', authController.postOtp);

router.get('/resetPassword', authController.getResetPassword);
router.post('/resetPassword', authController.postResetPassword);

router.get('/updatePassword', authController.getUpdatePassword);
router.post('/updatePassword', authController.postUpdatePassword);


router.get('/signup', authController.getSignup);
router.post('/signup', authController.postSignup);



module.exports = router;