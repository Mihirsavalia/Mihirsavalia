const express = require('express');

const router = express.Router();

const adminController = require('../controller/admin');
const isAuth = require('../middleware/isAuthMiddleware');


router.get('/add-product', isAuth, adminController.getAddProduct);
router.post('/add-product', isAuth, adminController.postAddProduct);

router.get('/products', isAuth, adminController.adminGetProducts);

router.get('/edit-product/:id', isAuth, adminController.getEditProduct);
router.post('/edit-product', isAuth, adminController.postEditproduct);

router.get('/products/:id', isAuth, adminController.getDeleteproduct);


module.exports = router;
