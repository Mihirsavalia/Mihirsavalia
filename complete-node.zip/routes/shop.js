const express = require('express');

const router = express.Router();

const shopController = require('../controller/shop');
const isAuth = require('../middleware/isAuthMiddleware');
const auth = require('../middleware/auth');

router.get('/', auth, shopController.getIndex);
router.get('/product-list', auth, shopController.getShopProduct);

router.get('/product-list/:productId', shopController.getProductDetails);

router.get('/cart', isAuth, shopController.getCart);
router.post('/cart', isAuth, shopController.postCart);
router.post('/cart-delete-item', isAuth, shopController.postDeleteCartItem);

router.get('/orders', isAuth, shopController.getOrder);
router.post('/create-order', isAuth, shopController.postOrder);

router.get('/checkout', isAuth, shopController.getCheckout);

module.exports = router;