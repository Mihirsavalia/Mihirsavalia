require('dotenv').config()
const path = require('path');

const express = require('express');
const bodyParser = require('body-parser');

const mongoose = require('mongoose');
const session = require('express-session');
const MongoDBStore = require('connect-mongodb-session')(session);

const jwt = require('jsonwebtoken');
const cors = require('cors');
const cookieParser = require('cookie-parser');   

const port = process.env.PORT;
const MONGODB_URI =process.env.MONGODB_URI ;

const adminRoutes = require('./routes/admin');
const shopRoutes = require('./routes/shop');
const authRoutes = require('./routes/auth');
const error404 = require('./controller/error');

const User = require('./models/userMongoose');

const app = express();

//CORS Policy
app.use(cors());

const store = new MongoDBStore({
    uri: MONGODB_URI,
    collection: 'sessions'
});


app.set('view engine', 'ejs');
app.set('views', 'views');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cookieParser());

app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: false,
    store: store
}))

app.use((req, res, next) => {
    if (!req.session.user) {
        return next();
    }
    User.findById(req.session.user._id)
        .then(user => {
            req.user = user;
            next();
        })
        .catch(err => console.log(err));
});

app.use((req, res, next) => {
    res.locals.isAuthenticated = req.session.isLoggedIn;
    next();
});

app.use(adminRoutes);
app.use(shopRoutes);
app.use(authRoutes);

app.use(express.static(path.join(__dirname, 'public')));

app.use(error404.get404);

mongoose.set('strictQuery', true);

mongoose.connect(MONGODB_URI)
    .then(() => {
        app.listen(port, () => {
            console.log(`Server is Running On http://localhost:${port}`)
        });
    })
    .catch(err => console.log(err));


