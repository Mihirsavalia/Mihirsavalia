const Product = require('../models/productMongoose');
const User = require('../models/userMongoose');

//console.log() - ctrl+alt+l
exports.getAddProduct = (req, res, next) => {
    res.render('admin/add-product',
        {
            pageTitle: 'Add-product',
            path: '/admin/add-product',
            isAuthenticated: req.session.isLoggedIn
        });
};

exports.postAddProduct = (req, res, next) => {
    const { title, imageUrl, price, description } = req.body;
    // var title = String(req.body.title);
    // var imageUrl = String(req.body.imageUrl);
    // var price = Number(req.body.price);
    // var description = String(req.body.description);
    const product = new Product({
        title: title,
        imageUrl: imageUrl,
        price: price,
        description: description,
        userId: req.user._id,
    });
    product.save()
        .then(() => {
            res.redirect('/');
        })
        .catch(err => console.log(err));
};


exports.adminGetProducts = (req, res, next) => {
    Product.find()
        // it will use for select the columns from table which we want to display
        // .select('title imageUrl price -_id')

        // it will return the combine table data like it will return name along with userId 
        // .populate('userId','name')
        .then((rows) => {
            var size = rows.length;
            res.render('admin/products',
                {
                    products: rows,
                    size: size,
                    pageTitle: 'Admin product',
                    path: '/admin/products',
                    isAuthenticated: req.session.isLoggedIn
                });

        })
        .catch(err => console.log(err));
};

exports.getEditProduct = (req, res, next) => {
    const productId = req.params.id;
    Product.findById(productId)
        .then(rows => {
            var size = rows.length;
            res.render('admin/edit-product',
                {
                    size: size,
                    products: rows,
                    pageTitle: 'Edit-product',
                    path: '/admin/edit-product',
                    isAuthenticated: req.session.isLoggedIn
                });
        })
        .catch(err => console.log(err));
};

exports.postEditproduct = (req, res, next) => {
    const productId = req.body.update;
    const { title, imageUrl, price, description } = req.body;

    // var title = String(req.body.title);
    // var imageUrl = String(req.body.imageUrl);
    // var price = Number(req.body.price);
    // var description = String(req.body.description);

    Product.findById(productId)
        .then(result => {
            result.title = title;
            result.imageUrl = imageUrl;
            result.price = price;
            result.description = description;
            return result.save();
        })
        .then(() => {
            res.redirect('/products');
        })
        .catch(err => console.log(err));
};

exports.getDeleteproduct = (req, res, next) => {

    const productId = req.params.id;

    Product.findByIdAndRemove(productId)
        .then(() => {
            res.redirect('/products');
        })
        .catch(err => console.log(err));
};