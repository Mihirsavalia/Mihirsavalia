const Product = require('../models/productMongoose');
const Order = require('../models/orderMongoose');

exports.getIndex = (req, res, next) => {

    Product.find()
        .then(rows => {
            var size = rows.length;
            res.render('shop/index',
                {
                    products: rows,
                    size: size,
                    pageTitle: 'Shop',
                    path: '/',
                    isAuthenticated: req.session.isLoggedIn
                });

        })
        .catch(err => console.log(err));
};

exports.getShopProduct = (req, res, next) => {
    Product.find()
        .then((rows) => {
            var size = rows.length;
            res.render('shop/product-list',
                {
                    products: rows,
                    size: size,
                    pageTitle: 'All Products',
                    path: '/shop/product-list',
                    isAuthenticated: req.session.isLoggedIn
                });

        })
        .catch(err => console.log(err));
};

exports.getProductDetails = (req, res, next) => {
    const productId = req.params.productId;
    Product.findById(productId)
        .then((product) => {
            res.render('shop/product-details',
                {
                    id: productId,
                    products: product,
                    pageTitle: 'Product details',
                    path: '/shop/product-list',
                    isAuthenticated: req.session.isLoggedIn

                });
        })
        .catch(err => console.log(err));
};


exports.getCart = (req, res, next) => {
    let totalPrice = 0;

    req.user
        .populate('cart.items.productId')
        // .execPopulate()
        .then(user => {
            const products = user.cart.items;
            for (let i = 0; i < products.length; i++) {
                totalPrice = totalPrice + products[i].price;
            }

            //Set Cookie totalPrice = totalPrice  
            res.cookie('totalPrice', totalPrice, { httpOnly: true })
            res.render('shop/cart',
                {
                    totalPrice: totalPrice,
                    products: products,
                    pageTitle: 'Cart',
                    path: '/shop/cart',
                    isAuthenticated: req.session.isLoggedIn
                });
        })
        .catch(err => console.log(err));
};

exports.postCart = (req, res, next) => {
    const productId = req.body.productId;

    Product.findById(productId)
        .then(product => {
            return req.user.addToCart(product);
        })
        .then(result => {
            res.redirect('/cart');
        })
        .catch(err => console.log(err));
};

exports.postDeleteCartItem = (req, res, next) => {
    const productId = req.body.productId;
    req.user
        .removeFromCart(productId)
        .then(result => {
            res.redirect('/cart');
        })
        .catch(err => console.log(err));
}

exports.postOrder = (req, res, next) => {
    //Get totalPrice Using Cookie
    // const totalPrice = req.get('Cookie').split(';')[1].trim().split('=')[1];
    const totalPrice = req.body.totalPrice;
    req.user.populate('cart.items.productId')
        // .execPopulate()
        .then(user => {
            const products = user.cart.items.map(i => {
                return { quantity: i.quantity, product: { ...i.productId._doc } }
            });
            const order = new Order({
                user: {
                    email: req.user.email,
                    userId: req.user
                },
                products: products,
                totalPrice: totalPrice
                // totalPrice: req.body.total,
            });
            return order.save();
        })
        .then(result => {
            req.user.clearCart();
        })
        .then(() => {
            res.redirect('/orders');
        })
        .catch(err => console.log(err));
};

exports.getOrder = (req, res, next) => {
    Order.find({ 'user.userId': req.user._id })
        .then(orders => {
            res.render('shop/orders',
                {
                    orders: orders,
                    pageTitle: 'Orders',
                    path: '/shop/orders',
                    isAuthenticated: req.session.isLoggedIn
                });
        })
        .catch(err => console.log(err));
};

exports.getCheckout = (req, res, next) => {
    res.render('shop/checkout',
        {
            pageTitle: 'Checkout',
            path: '/checkout',
            isAuthenticated: req.session.isLoggedIn
        });
};