require('dotenv').config()
const bcrypt = require('bcryptjs');
const User = require('../models/userMongoose');
const jwt = require('jsonwebtoken');

const nodemailer = require('nodemailer');


const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    requireTLS: true,
    auth: {
        user: "mihirsavaliya758@gmail.com",
        pass: "dnhltdtiedgkwrhq"
    }
});

exports.getLogin = (req, res, next) => {
    // const isLoggedIn = req.get('Cookie').split(';')[0].trim().split('=')[1];
    // console.log("AUTH LOGIN :",req.session.isLoggedIn);
    res.render('auth/login',
        {
            pageTitle: 'Login',
            path: '/login',
            isAuthenticated: false
        });
};

let generateOtp = 0;
let passwordResetOtp = 0;

exports.postLogin = (req, res, next) => {
    const { email, password } = req.body;

    generateOtp = Math.floor(1000 + Math.random() * 9000);
    console.log("🚀 ~ file: auth.js:38 ~ generateOtp:", generateOtp)

    User.findOne({ email: email })
        .then(user => {
            if (!user) {
                res.send({ "status": "failed", "message": "You are not registred user" })
                return res.redirect('/login')
            }
            bcrypt
                .compare(password, user.password)
                .then(doMatch => {
                    if (doMatch) {
                        req.session.isLoggedIn = true;
                        req.session.user = user;
                        return req.session.save(err => {
                            //Generate JWT Token
                            const token = jwt.sign(
                                { userId: user._id },
                                process.env.JWT_SECRET_KEY,
                                { expiresIn: '1d' }
                            );
                            res.cookie('token', token, { httpOnly: true });
                            const message = {
                                from: 'mihirsavaliya758@gmail.com',
                                to: email,
                                subject: 'OTP',
                                html: `<p>Your OTP is : </p><h4>${generateOtp}</h4>`
                            };
                            transporter.sendMail(message, (error, info) => {
                                if (error) {
                                    console.log(error)
                                }
                                else {
                                    console.log('Email sent ...', info.response)
                                }
                            })
                            res.redirect('/otp')
                        })
                    }
                    res.redirect('/login')
                })
                .catch(err => console.log(err))
        })
        .catch(err => console.log(err));
};

exports.postLogout = (req, res, next) => {
    req.session.destroy(() => {
        res.redirect('/')
    });
}
exports.getOtp = (req, res, next) => {
    res.render('auth/otp',
        {
            pageTitle: 'OTP',
            path: '/OTP',
            isAuthenticated: false
        });
}
exports.postOtp = (req, res, next) => {
    const otp = Number(req.body.otp);
    if (generateOtp === otp) {
        generateOtp = 0;
        res.redirect('/')
    }
    else if (passwordResetOtp === otp) {
        res.redirect('/updatePassword')
    }
    else {
        res.redirect('/otp')
        console.log('error');
    }
}

exports.getSignup = (req, res, next) => {
    res.render('auth/signup',
        {
            pageTitle: 'Sign UP',
            path: '/signup',
            isAuthenticated: false
        });
};

exports.postSignup = (req, res, next) => {
    const { name, email, password, confirm_password } = req.body;
    User.findOne({ email: email })
        .then(userDoc => {
            if (userDoc) {
                res.send({ "status": "failed", "message": "Email already exists" })
            }
            else {
                if (name && email && password && confirm_password) {
                    if (password === confirm_password) {
                        return bcrypt.hash(password, 12)
                            .then(hashPassword => {
                                const user = new User({
                                    name: name,
                                    email: email,
                                    password: hashPassword,
                                    cart: { items: [] }
                                });
                                return user.save();
                            });
                    } else {
                        res.send({ "status": "failed", "message": "Password & Confirm password doesn't match" })
                    }
                }
                else {
                    res.send({ "status": "failed", "message": "All fields are required" });
                }
            }
        })
        .then(result => {
            const message = {
                from: 'mihirsavaliya758@gmail.com',
                to: email,
                subject: 'SignUp Successfully...',
                html: '<h1>You Successfully Signed UP!</h1>'
            };
            transporter.sendMail(message, (error, info) => {
                if (error) {
                    console.log(error)
                }
                else {
                    console.log('Email sent ...', info.response)
                }
            })
            res.redirect('/login')
        })
        .catch(err => console.log(err))
};

exports.getResetPassword = (req, res, next) => {
    res.render('auth/resetPassword',
        {
            pageTitle: 'Reset Password',
            path: '/resetPassword',
            isAuthenticated: false
        });
};

var globalId;

exports.postResetPassword = (req, res, next) => {
    const { email } = req.body;
    passwordResetOtp = Math.floor(1000 + Math.random() * 9000);
    console.log("🚀 ~ file: auth.js:179 ~ passwordResetOtp:", passwordResetOtp)
    User.findOne({ email: email })
        .then(result => {
            globalId = result._id;
            if (!result) {
                console.log("Error in sending email...");
            } else {
                console.log("Result : ", result.email);
                const message = {
                    from: 'mihirsavaliya758@gmail.com',
                    to: result.email,
                    subject: 'OTP',
                    html: `<p>Your OTP is : </p><h4>${passwordResetOtp}</h4>`
                };
                transporter.sendMail(message, (error, info) => {
                    if (error) {
                        console.log(error)
                    }
                    else {
                        console.log('Email sent ...', info.response)
                    }
                })
            }
        })
        .catch(err => console.log(err));

    res.redirect('/otp')
};

exports.getUpdatePassword = (req, res, next) => {
    res.render('auth/updatePassword',
        {
            pageTitle: 'Update Password',
            path: '/updatePassword',
            isAuthenticated: false
        });
};

exports.postUpdatePassword = (req, res, next) => {
    const { password, confirm_password } = req.body;
    
    if (password === confirm_password) {
        return bcrypt.hash(password, 12)
            .then(hashPassword => {
                User.findByIdAndUpdate({ _id: globalId })
                    .then(result => {
                        result.password = hashPassword;
                        result.save()
                        res.redirect('/login')
                    })
                    .catch(err => console.log(err))
            });
    } else {
        res.send({ "status": "failed", "message": "Password & Confirm password doesn't match" })
    }
};