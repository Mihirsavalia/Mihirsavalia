let s1 = '[ { [ { {   }  ] } ]'
let open = []
let close = []
let last;
for (let i of s1) {
    if (i == '{' || i == '(' || i == '[') {
        open.push(i)
    }
    if (i == '}' || i == ')' || i == ']') {
        if (i == '}') {
            close.push("{")
        }
        if (i == ')') {
            close.push("(")
        }
        if (i == ']') {
            close.push("[");
        }
    }
}
var k = 0;
var f = open.length;
for (let i = open.length - 1; i >= 0; i--) {

    // console.log("", open[i], close[k])

    var fal = open[i] == close[k];
    if (!fal) {
        console.log(k,fal)
        break;
    }
    k = k + 1;
}
if (fal) {
    console.log(k,fal)
}