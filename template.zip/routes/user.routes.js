const express = require('express');
const router = express.Router();

const userController = require('../controllers/user.controller')
/* GET home page. */
router.get('/',userController.getDashboard);

router.get('/signup',userController.getSignup);
router.get('/login',userController.getLogin);
router.get('/display',userController.getDisplay);
router.get('/profile',userController.getProfile);

module.exports = router;
