require('dotenv').config();
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');

const port = process.env.PORT;

const error404 = require('./controllers/error.controller')
const usersRouter = require('./routes/user.routes');

const app = express();

// view engine setup
app.set('view engine', 'ejs');
app.set('views', 'views');

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use(usersRouter);

// catch 404 and forward to error handler
app.use(error404.get404);

app.listen(port, () => {
  console.log(`App is running on ${port}`)
})

