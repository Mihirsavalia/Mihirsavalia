exports.getDashboard = (req, res, next) => {
    res.render('dashboard');
}
exports.getSignup = (req, res, next) => {
    res.render('signup');
}
exports.getLogin = (req, res, next) => {
    res.render('login');
}
exports.getDisplay = (req, res, next) => {
    res.render('display');
}
exports.getProfile = (req, res, next) => {
    res.render('profile');
}